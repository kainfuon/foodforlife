import React from 'react'
import './Orders.css'

const Orders = () => {
  return (
    <div>
      orders
    </div>
  )
}

export default Orders
