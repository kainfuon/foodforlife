import React from 'react'
import './List.css'

const List = () => {
  return (
    <div>
      
    </div>
  )
}

export default List
